<?php 
         ob_start();
	     require_once 'rip/configuration.php';
	     require_once 'rip/init.php';
		 
         if ($user -> LoggedIn()){
		 header('Location: index.php');
		 exit;
	     }
		 
if ($settings['cloudflare_set'] == '1') {
    $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

		 
unset($_SESSION['captcha']);
$_SESSION['captcha'] = rand(1, 100);
$x1 = rand(2,15);
$x2 = rand(1,20);
$x = SHA1(($x1 + $x2).$_SESSION['captcha']);
   
   
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <meta name="keywords" content="IP Stresser,Booter,Web Booter,free stresser,free ddos,ovh down,game down,ts3 ddos,ts3 down,stresser,free ip stresser">
  <meta name="description" content="Create a free account to test our plans up to 200 gbps. The best free ip stresser service on the market!" />
        <title>Oblivion | Register</title>
        <meta content="Oblivion Register" name="description" />
        <meta content="Oblivion" name="author" />
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
        <script>
          var answer="<?php echo $x; ?>";
        </script>
    </head>

    <body class="pb-0">

        <div class="home-btn d-none d-sm-block">
            <a href="index.php" class="text-white"></a>
        </div>
        
        <div class="wrapper-page">

            <div class="card overflow-hidden account-card mx-3">
                
                <div class="bg-primary p-4 text-white text-center position-relative">
                    <h4 class="font-20 m-b-5">Free Register!</h4>
                    <p class="text-white-50 mb-4">Get your free Oblivion account now.</p>
                    <a class="logo logo-admin"><img src="assets/images/avatar.png" height="80" alt="logo"></a>
                </div>
                <div class="account-card-content">  

                    <form class="form-horizontal m-t-30" onsubmit="return false">
                        <div id="alert" style="display:none"></div>
                        <div id="loader" style="display:none"></div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" placeholder="Enter email">
                        </div>

                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" id="username" placeholder="Enter username">
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password" placeholder="Enter password">
                        </div>
                        <div class="form-group">
                            <label for="rpassword">Verify Password</label>
                            <input type="password" class="form-control" id="rpassword" placeholder="Enter verify password">
                        </div>
                        <div class="form-group">
                            <label for="question">Question</label>
                            <input type="text" class="form-control" id="question"  placeholder="<?php echo 'How much is '.$x1.'+'.$x2.'?'; ?>">
                        </div>
                        <div class="form-group row m-t-20">
                            <div class="col-12 text-right">
                                <center><button class="btn btn-primary w-md waves-effect waves-light" id="register">Register</button></center>
                            </div>
                        </div>

                        <div class="form-group m-t-10 mb-0 row">
                            <div class="col-12 m-t-20">
                                <p>Already have an account? <a href="login.php" class="font-500 text-primary"> Login now!</a> </p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
        <!-- end wrapper-pags -->

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
        <script>
        $('#register').on('click',function(){
          var username=$('#username').val();
          var email=$('#email').val();
          var password=$('#password').val();
          var rpassword=$('#rpassword').val();
          var question=$('#question').val();

          document.getElementById("alert").style.display="none";
          document.getElementById("loader").style.display="inline"; 
          var xmlhttp;
          if (window.XMLHttpRequest)
            {
            xmlhttp=new XMLHttpRequest();
            }
          else
            {
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
          xmlhttp.onreadystatechange=function()
            {
            if (xmlhttp.readyState==4 && xmlhttp.status==200)
              {
              document.getElementById("alert").innerHTML=xmlhttp.responseText;
            document.getElementById("loader").style.display="none";
            document.getElementById("alert").style.display="inline";
            if (xmlhttp.responseText.search("Redirecting") != -1)
            {
            setInterval(function(){window.location="index.php"},3000);
              }
              }
            }
          xmlhttp.open("POST","includes/login.php?type=register",true);
          xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
          xmlhttp.send("username=" + username + "&email=" + email + "&password=" + password + "&rpassword=" + rpassword + "&question=" + question + "&answer=" + answer);
        })
        </script>
    </body>

</html>