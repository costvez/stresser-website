<?php
	$page = "Api System";
	require_once 'header.php'; 
?>


<?php
	if(isset($_POST['gen_key'])){
		if(isset($_SESSION['username'])){
			genKey($_SESSION['username'], $odb);
			header('Location: api.php');
		}
	}
	if(isset($_POST['disable_key'])){
		if(isset($_SESSION['username'])){
			disableKey($_SESSION['username'], $odb);
			header('Location: api.php');
		}
	}

	function genKey($username, $odb){
		$newkey = generateRandomString(16);
		$stmt2 = $odb->query("UPDATE users SET apikey='$newkey' WHERE username='$username'");
	}
	function disableKey($username, $odb){
		$stmt2 = $odb->query("UPDATE users SET apikey='0' WHERE username='$username'");
	}
	function generateRandomString($length = 10){
		$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
		$charactersLength = strlen($characters);
		$randomString = '';
		for($i=0;$i<$length;$i++){
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	$stmt = $odb->prepare("SELECT apikey FROM users WHERE username=:login");
	$stmt->bindParam("login", $_SESSION['username'], PDO::PARAM_STR);
	$stmt->execute();
	$key = $stmt->fetchColumn(0);
?>

  <!-- Page Content -->
		
    <div class="container-fluid">
      <!-- .row -->

      <!--/.row -->
      <!-- .row -->
	  <div class="widget-content">

</div> 
<br> </br>
<br> </br>
<br> </br>
<br> </br>
<br> </br>
          <div class="white-box">
		  	<p class="box-title">API Request URL</p>
		  	<form method="POST">
		  		<?php if($key == '0'){?>
	            <input class="form-control" type="text" value="API is unavailable or api-key is disabled! Click 'Generate new api-key'." readonly="" style="color:black;">
	            <?php }else{?>
				<?php if($user->api($odb)){?>
				<?php if($user->isVip($odb)){?>
	            <input class="form-control" type="text" value="https://oblivion.rip/client/api/api.php?key=<?php echo $key;?>&host=[host]&port=[port]&time=[time]&method=[method]" readonly="" style="color:black;">
	            <?php }else{?>
				<input class="form-control" type="text" value="https://oblivion.rip/client/api/api.php?key=<?php echo $key;?>&host=[host]&port=[port]&time=[time]&method=[method]" readonly="" style="color:black;">
				<?php }?>
				<?php }else{?>
				<input class="form-control" type="text" value="You need api access for use this!" readonly="" style="color:black;">
				<?php }?>
				<?php }?>
	            <br><button type="submit" class="btn btn-primary" name="gen_key">Generate Key</button> <button type="submit" class="btn btn-danger" name="disable_key">Disable api-key</button>
	        </form>
          </div>
		  <br><br>
		  
		  

			</div>
		</div>
	</div>
</div>
<br><br><br>
<br>
<br>
<br>
<br>



<?php

	require_once 'footer.php';
	
?>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5d5281c677aa790be32eac19/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->