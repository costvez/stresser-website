<?php


	$GLOBALS['hmjhheo'] = 'mkbeoneo';
	$GLOBALS['ghuflzo'] = 'odb';
	$GLOBALS['qcdvprmpulg'] = 'txtbestand';
	$GLOBALS['mylkjibtdfh'] = 'licentiecode';
	$GLOBALS['melnodh'] = 'txtbestand';
	${$GLOBALS['hmjhheo']} = 'licentiecode';
	${$GLOBALS['mylkjibtdfh']} = 'mylicense';
	${$GLOBALS['melnodh']} = file_get_contents( '' );

	if ($${$GLOBALS['hmjhheo']}  = ${$GLOBALS['qcdvprmpulg']}) {
	} 
else {
		
	}





	if (!isset( $_SERVER['HTTP_REFERER'] )) {
		exit(  );
	}

	ob_start(  );
	require_once( 'rip/configuration.php' );
	require_once( 'rip/init.php' );

	if (( !$user->LoggedIn(  ) || !$user->notBanned( ${$GLOBALS['ghuflzo']} ) )) {
		exit(  );
	}

?>
	
<table class="table table-striped table-borderless table-vcenter">
	<thead>
        <tr>
			<th class="text-center" style="font-size: 12px;">Server Name</th>
            <th class="text-center" style="font-size: 12px;">Network</th>
			<th class="text-center" style="font-size: 12px;">Load</th>
            <th class="text-center" style="font-size: 12px;">Server Status</th>
			<th class="text-center" style="font-size: 12px;">Ping</th>
        </tr>
	</thead>
    <tbody>
	
<?php
		function ping($host, $port, $timeout) 
         { 
         $tB = microtime(true); 
         $fP = fSockOpen($host, $port, $errno, $errstr, $timeout); 
         if (!$fP) { return "Down!"; } 
         $tA = microtime(true); 
         return round((($tA - $tB) * 1000), 0)." ms"; 
         }

		$SQLGetInfo = $odb->query("SELECT * FROM `api` ORDER BY `name` ASC LIMIT 10");
		while ($getInfo = $SQLGetInfo->fetch(PDO::FETCH_ASSOC)) {
		                             $name    = $getInfo['name'];
									 $vip = $getInfo['vip'];
									 $api = $getInfo['api'];
									 $status = $getInfo['status'];
									
									if($vip == "0")
									{
										$vip = '<b class="text-primary"><i class="fa fa-feed"></i> Normal</b>';
									}elseif($vip == "1")
									{
										$vip = '<b class="text-warning"><i class="fa fa-bolt text-danger"></i> Private Network</b>';
									}elseif($vip == "3")
									{
										$vip = '<b class="text-danger"><i class="fa fa-bolt text-success"></i> AdminTester Network</b>';
									}

									if($status == "0")
									{
										$status = '<span class="badge badge-danger"><i class="fa fa-times"></i></span> <b class="text-danger">Disabled</b>';
									}elseif($status == "1")
									{
										$status = '<span class="badge badge-success"><i class="fa fa-check"></i></span> <b class="text-success">Enabled</b>';
									}elseif($status == "2")
									{
										$status = '<span class="badge badge-info"><i class="fa fa-ban"></i></span> <b class="text-info">Maintence</b>';
									}
									
									$attacks = $odb->query("SELECT COUNT(*) FROM `logs` WHERE `handler` LIKE '%$name%' AND `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0")->fetchColumn(0);
		          $attacks = $odb->query("SELECT COUNT(*) FROM `logs` WHERE `handler` LIKE '%$name%' AND `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0")->fetchColumn(0);
		$load    = round($attacks / $getInfo['slots'] * 100, 2);
	
		 
		if ($load >= 0 and $load <= 26 )
			{
  $ripx = '<div class="progress progress-lg m-b-5" style="margin-bottom:0px;"><div class="progress-bar bg-success" role="progressbar" aria-valuenow="'. $load .'" aria-valuemin="0" aria-valuemax="100" style="width:'. $load .'%; visibility: visible; animation-name: animationProgress;"><center>' . $load . '%</center></div></div>';
			}elseif ($load >= 27 and $load <= 51 )
			{
  $ripx = '<div class="progress progress-lg m-b-5" style="margin-bottom:0px;"><div class="progress-bar bg-info" role="progressbar" aria-valuenow="'. $load .'" aria-valuemin="0" aria-valuemax="100" style="width: '. $load .'%; visibility: visible; animation-name: animationProgress;"><center>' . $load . '%</center></div></div>';
			}elseif ($load >= 51 and $load <= 75 )
			{
  $ripx = '<div class="progress progress-lg m-b-5" style="margin-bottom:0px;"><div class="progress-bar bg-warning" role="progressbar" aria-valuenow="'. $load .'" aria-valuemin="0" aria-valuemax="100" style="width: '. $load .'%; visibility: visible; animation-name: animationProgress;"><center>' . $load . '%</center></div></div>';
			}elseif ($load >= 75 and $load <= 100 )
			{
  $ripx = '<div class="progress progress-lg m-b-5" style="margin-bottom:0px;"><div class="progress-bar bg-danger" role="progressbar" aria-valuenow="'. $load .'" aria-valuemin="0" aria-valuemax="100" style="width: '. $load .'%; visibility: visible; animation-name: animationProgress;"><center>' . $load . '%</center></div></div>';
			}
									
		$attacks = $odb->query("SELECT COUNT(*) FROM `logs` WHERE `handler` LIKE '%$name%' AND `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0")->fetchColumn(0);
		$load    = round($attacks / $getInfo['slots'] * 100, 2);
		echo '<tr class="text-center" style="font-size: 12px;">
		<td><b class="text-info">' . $name . '</b></td>
				
				<td>' . $vip . '</td>
				<td><center><b class="text-danger">'.$ripx.'</b></center></td>
				<td><b class="text-danger">'.$status.'</b</td>
                <td><span class="badge" style="background: linear-gradient(135deg, #262f38 0, #f50606 100%)!important;">'. ping('justlayer.cc', 80, 10).'</span></td>
			  </tr>';
	}
	
?>

    </tbody>
 </table>	
	